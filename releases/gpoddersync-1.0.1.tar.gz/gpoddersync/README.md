# nextcloud-gpodder
nextcloud app that replicates basic gpodder.net api 

This app serves as synchronization endpoint for AntennaPod: https://github.com/AntennaPod/AntennaPod/pull/5243/
