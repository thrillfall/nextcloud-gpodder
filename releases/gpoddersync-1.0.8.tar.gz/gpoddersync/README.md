# nextcloud-gpodder
nextcloud app that replicates basic gpodder.net api 

This app serves as synchronization endpoint for AntennaPod: https://github.com/AntennaPod/AntennaPod/pull/5243/

#changelog:

1.0.7:
- accept only arrays on subscription change endpoint (thanks https://github.com/mattsches)
