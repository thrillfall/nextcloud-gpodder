# Changelog

## 1.0.8 - 2021-07-22
### Fixed
- convert timestamp from episode action request to format also mysql can process (#13)


## 1.0.7 – 2021-07-13
### Changed
- accept only arrays on subscription change endpoint (thanks https://github.com/mattsches)

