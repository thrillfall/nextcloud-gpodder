# Changelog

## 1.0.9 - 2021-07-27
### Changed
- save episode action timestamps as UTC (thanks @JohnOfUs)

## 1.0.8 - 2021-07-22
### Fixed
- convert timestamp from episode action request to format also mysql can process (#13)


## 1.0.7 – 2021-07-13
### Changed
- accept only arrays on subscription change endpoint (thanks https://github.com/mattsches)

